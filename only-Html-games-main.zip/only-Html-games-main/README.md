# Games
There are a bunch of games I have made. For some of them, you can add your image some are fully ready and some may need a server.
Just download the files as one big zip file and open the file then click "#Index.html" then that should open the game in a new tab some of the games will not open because of what type of browser you are on.
